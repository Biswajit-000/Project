import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rules")
public class RuleController {

    @Autowired
    private RuleRepository ruleRepository;

    // Parse the rule string into an AST
    private Node createRule(String ruleString) {
        String[] conditions = ruleString.split(" AND ");
        Node root = null;
        for (String condition : conditions) {
            if (root == null) {
                root = new Node("operand", null, null, condition.trim());
            } else {
                root = new Node("operator", root, new Node("operand", null, null, condition.trim()), "AND");
            }
        }
        return root;
    }

    // Combine rules into a single AST
    private Node combineRules(List<String> ruleStrings) {
        Node combinedRoot = null;
        for (String ruleStr : ruleStrings) {
            Node ruleAst = createRule(ruleStr);
            if (combinedRoot == null) {
                combinedRoot = ruleAst;
            } else {
                combinedRoot = new Node("operator", combinedRoot, ruleAst, "OR");
            }
        }
        return combinedRoot;
    }

    // Evaluate AST against user data
    private boolean evaluateRule(Node node, UserData userData) {
        if ("operand".equals(node.getType())) {
            String[] parts = node.getValue().split(" ");
            String key = parts[0];
            String operator = parts[1];
            int value = Integer.parseInt(parts[2]);

            switch (key) {
                case "age":
                    return compare(userData.getAge(), value, operator);
                case "salary":
                    return compare(userData.getSalary(), value, operator);
                case "experience":
                    return compare(userData.getExperience(), value, operator);
                case "department":
                    return operator.equals("=") && userData.getDepartment().equals(value);
            }
        } else if ("operator".equals(node.getType())) {
            if ("AND".equals(node.getValue())) {
                return evaluateRule(node.getLeft(), userData) && evaluateRule(node.getRight(), userData);
            } else if ("OR".equals(node.getValue())) {
                return evaluateRule(node.getLeft(), userData) || evaluateRule(node.getRight(), userData);
            }
        }
        return false;
    }

    private boolean compare(int dataValue, int ruleValue, String operator) {
        switch (operator) {
            case ">": return dataValue > ruleValue;
            case "<": return dataValue < ruleValue;
            case "=": return dataValue == ruleValue;
            default: return false;
        }
    }

    @PostMapping("/create")
    public String createRuleApi(@RequestBody RuleDto ruleDto) {
        Node ast = createRule(ruleDto.getRule());
        String serializedAst = ast.toString();
        ruleRepository.save(new Rule(serializedAst));
        return "Rule created: " + serializedAst;
    }

    @PostMapping("/combine")
    public String combineRulesApi(@RequestBody List<String> rules) {
        Node combinedAst = combineRules(rules);
        return "Combined AST: " + combinedAst.toString();
    }

    @PostMapping("/evaluate")
    public String evaluateRuleApi(@RequestBody EvaluationDto evaluationDto) {
        Node ast = createRule(evaluationDto.getAst()); // Simple parsing, assuming the AST string is valid.
        UserData userData = evaluationDto.getUserData();
        boolean result = evaluateRule(ast, userData);
        return "Evaluation result: " + result;
    }
}
