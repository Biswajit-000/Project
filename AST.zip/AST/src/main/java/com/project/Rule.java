import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Rule {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String ruleAst;  // JSON representation of the AST

    public Rule() {}

    public Rule(String ruleAst) {
        this.ruleAst = ruleAst;
    }

    public Long getId() {
        return id;
    }

    public String getRuleAst() {
        return ruleAst;
    }

    public void setRuleAst(String ruleAst) {
        this.ruleAst = ruleAst;
    }
}
